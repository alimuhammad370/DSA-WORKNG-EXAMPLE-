class TreeNode {
    int data;
    TreeNode left, right;

    public TreeNode(int data) {
        this.data = data;
        this.left = null;
        this.right = null;
    }
}

public class BinaryTree {
    TreeNode root;

    public boolean hasChildrenSumProperty(TreeNode node) {
        if (node == null || (node.left == null && node.right == null)) return true;
        int leftData = node.left != null ? node.left.data : 0;
        int rightData = node.right != null ? node.right.data : 0;
        if (node.data != leftData + rightData) return false;
        return hasChildrenSumProperty(node.left) && hasChildrenSumProperty(node.right);
    }

    public static void main(String[] args) {
        BinaryTree tree = new BinaryTree();
        tree.root = new TreeNode(10);
        tree.root.left = new TreeNode(8);
        tree.root.right = new TreeNode(2);
        tree.root.left.left = new TreeNode(3);
        tree.root.left.right = new TreeNode(5);
        tree.root.right.right = new TreeNode(2);

        System.out.println("Children Sum Property: " + tree.hasChildrenSumProperty(tree.root));
    }
}
