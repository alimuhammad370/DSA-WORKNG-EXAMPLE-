import java.util.Scanner;

class Node {
    char data;
    Node prev, next;

    Node(char data) {
        this.data = data;
    }
}

class TextEditor {
    Node head, tail, cursor;

    public void insertChar(char c) {
        Node newNode = new Node(c);
        if (cursor == null) {
            head = tail = cursor = newNode;
        } else {
            newNode.prev = cursor;
            newNode.next = cursor.next;
            if (cursor.next != null) cursor.next.prev = newNode;
            else tail = newNode;
            cursor.next = newNode;
            cursor = newNode;
        }
    }

    public void deleteChar() {
        if (cursor == null) return;
        if (cursor == head && cursor == tail) {
            head = tail = cursor = null;
        } else if (cursor == head) {
            head = head.next;
            head.prev = null;
            cursor = head;
        } else if (cursor == tail) {
            tail = tail.prev;
            tail.next = null;
            cursor = tail;
        } else {
            cursor.prev.next = cursor.next;
            cursor.next.prev = cursor.prev;
            cursor = cursor.prev;
        }
    }

    public void moveCursorLeft() {
        if (cursor != null && cursor.prev != null) {
            cursor = cursor.prev;
        }
    }

    public void moveCursorRight() {
        if (cursor != null && cursor.next != null) {
            cursor = cursor.next;
        }
    }

    public void displayText() {
        Node current = head;
        while (current != null) {
            if (current == cursor) System.out.print("|");
            System.out.print(current.data);
            current = current.next;
        }
        if (cursor == null) System.out.print("|");
        System.out.println();
    }
}

public class Main {
    public static void main(String[] args) {
        TextEditor editor = new TextEditor();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nText Editor:");
            editor.displayText();
            System.out.println("\nOptions:");
            System.out.println("1. Insert Character");
            System.out.println("2. Delete Character");
            System.out.println("3. Move Cursor Left");
            System.out.println("4. Move Cursor Right");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter character to insert: ");
                    char c = scanner.nextLine().charAt(0);
                    editor.insertChar(c);
                    break;
                case 2:
                    editor.deleteChar();
                    break;
                case 3:
                    editor.moveCursorLeft();
                    break;
                case 4:
                    editor.moveCursorRight();
                    break;
                case 5:
                    System.out.println("Exiting editor.");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }
}
