import java.util.HashSet;

public class FindDuplicate {

    public static int findDuplicate(int[] A) {
        HashSet<Integer> seen = new HashSet<>();
        for (int num : A) {
            if (seen.contains(num)) {
                return num;
            }
            seen.add(num);
        }
        return -1;
    }

    public static void main(String[] args) {
        int[] A = {1, 3, 4, 2, 2};
        System.out.println("Repeated integer in A: " + findDuplicate(A));
    }
}
