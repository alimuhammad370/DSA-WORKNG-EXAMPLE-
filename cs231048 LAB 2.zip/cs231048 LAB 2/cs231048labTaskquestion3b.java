import java.util.HashMap;
import java.util.ArrayList;
import java.util.List;

public class FindRepeatedElements {

    public static List<Integer> findRepeatedElements(int[] B) {
        HashMap<Integer, Integer> counts = new HashMap<>();
        List<Integer> repeated = new ArrayList<>();
        
        for (int num : B) {
            counts.put(num, counts.getOrDefault(num, 0) + 1);
        }
        
        for (int num : counts.keySet()) {
            if (counts.get(num) > 1) {
                repeated.add(num);
            }
        }
        
        return repeated;
    }

    public static void main(String[] args) {
        int[] B = {1, 2, 3, 4, 5, 6, 2, 3, 1, 7, 8, 3, 9, 10, 5};
        System.out.println("Repeated integers in B: " + findRepeatedElements(B));
    }
}
