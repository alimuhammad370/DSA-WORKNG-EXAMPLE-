import java.util.ArrayList;

public class ArraySearch {

    public static void searchItem(ArrayList<Integer> list, int item) {
        int itemIndex = list.indexOf(item);

        if (itemIndex == -1) {
            System.out.println("The item " + item + " does not exist in the array.");
            return;
        }

        System.out.print("Right neighbor(s): ");
        if (itemIndex + 1 < list.size()) {
            System.out.print(list.get(itemIndex + 1));
            if (itemIndex + 2 < list.size()) {
                System.out.print(", " + list.get(itemIndex + 2));
            }
            System.out.println();
        } else {
            System.out.println("No right neighbor.");
        }

        System.out.print("Left neighbor(s): ");
        if (itemIndex - 1 >= 0) {
            System.out.print(list.get(itemIndex - 1));
            if (itemIndex - 2 >= 0) {
                System.out.print(", " + list.get(itemIndex - 2));
            }
            System.out.println();
        } else {
            System.out.println("No left neighbor.");
        }
    }

    public static void main(String[] args) {
        ArrayList<Integer> list = new ArrayList<>();
        list.add(10);
        list.add(20);
        list.add(30);
        list.add(40);
        list.add(50);

        int itemToFind = 30;

        searchItem(list, itemToFind);
    }
}
