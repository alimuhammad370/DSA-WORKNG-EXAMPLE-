import java.util.Scanner;

public class MatrixDiagonalSums {

    public static int calculateLeftDiagonalSum(int[][] matrix, int size) {
        int sum = 0;
        for (int i = 0; i < size; i++) {
            sum += matrix[i][i];
        }
        return sum;
    }

    public static int calculateRightDiagonalSum(int[][] matrix, int size) {
        int sum = 0;
        for (int i = 0; i < size; i++) {
            sum += matrix[i][size - i - 1];
        }
        return sum;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = scanner.nextInt();
        int[][] matrix = new int[n][n];

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                matrix[i][j] = scanner.nextInt();
            }
        }

        int leftDiagonalSum = calculateLeftDiagonalSum(matrix, n);
        System.out.println(leftDiagonalSum);

        int rightDiagonalSum = calculateRightDiagonalSum(matrix, n);
        System.out.println(rightDiagonalSum);

        scanner.close();
    }
}
