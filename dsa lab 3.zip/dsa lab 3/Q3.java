class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class SinglyLinkedList {
    Node head;

    public SinglyLinkedList() {
        head = null;
    }

    public void append(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    public SinglyLinkedList copyList() {
        SinglyLinkedList copy = new SinglyLinkedList();
        Node current = head;
        while (current != null) {
            copy.append(current.data);
            current = current.next;
        }
        return copy;
    }

    public SinglyLinkedList reverseList() {
        SinglyLinkedList reversed = new SinglyLinkedList();
        Node current = head;
        while (current != null) {
            Node newNode = new Node(current.data);
            newNode.next = reversed.head;
            reversed.head = newNode;
            current = current.next;
        }
        return reversed;
    }

    public void printList() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}

public class Main {
    public static void main(String[] args) {
        SinglyLinkedList list = new SinglyLinkedList();

        list.append(10);
        list.append(20);
        list.append(30);
        list.append(40);
        list.append(50);

        System.out.print("Original List: ");
        list.printList();

        SinglyLinkedList originalCopy = list.copyList();

        SinglyLinkedList reversedList = list.reverseList();

        System.out.print("Original List (Copy): ");
        originalCopy.printList();

        System.out.print("Reversed List: ");
        reversedList.printList();
    }
}
